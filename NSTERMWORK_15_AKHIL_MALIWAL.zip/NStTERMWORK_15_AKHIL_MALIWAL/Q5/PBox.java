import java.util.*;

public class PBox
{
	public static List<Integer> generate_key(int len)
	{
		List<Integer> positions = new ArrayList<Integer>();
		for(int i=0;i<len;i++)
			positions.add(i);
		
		Collections.shuffle(positions);
		return positions;
	}
	
	public static String encrypt(String input, List<Integer> key)
	{
		StringBuilder cipher = new StringBuilder();
		for(int x : key)
			cipher.append(input.charAt(x));
		
		return cipher+"";
	}
	
	public static String decrypt(String cipher, List<Integer> key)
	{
		StringBuilder msg = new StringBuilder();
		for(int x=0;x<key.size();x++)
			msg.append(cipher.charAt(key.indexOf(x)));
		
		return msg+"";
	}
	
	public static void main(String args[])
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter Message: ");
		String input = scan.nextLine().replace(" ","$");
		
		List<Integer> key = generate_key(input.length());
		
		String cipher = encrypt(input,key);
		System.out.println("Encrypted Message: " + cipher);
		
		String msg = decrypt(cipher,key);
		System.out.println("Decrypted Message: " + msg.replace("$"," "));
	}
}