import java.util.Scanner;
import java.io.*;
import java.net.*;

public class Client
{
	public static void main(String args[]) throws IOException
	{
		Scanner scan = new Scanner(System.in);
		Socket cs = new Socket("localhost",1234);
		
		System.out.print("\nEnter String to be Sent: ");
		String msg = scan.nextLine();
		
		DataOutputStream out = new DataOutputStream(cs.getOutputStream());
		out.writeUTF(msg);
		
		System.out.println("Message Sent..");
	}
}
