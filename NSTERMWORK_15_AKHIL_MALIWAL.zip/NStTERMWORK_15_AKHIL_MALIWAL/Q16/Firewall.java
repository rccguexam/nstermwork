import java.util.*;
import java.io.*;
import java.net.*;

public class Firewall
{
	public static void main(String args[]) throws IOException
	{
		ServerSocket ss = new ServerSocket(1234);
		Socket con = ss.accept();
		
		DataInputStream input = new DataInputStream(con.getInputStream());
		String s;
		s=input.readUTF();;
		System.out.println("String successfully received: "+s);
		Socket sk1=new Socket("127.0.0.1",3456);
		DataOutputStream dos=new DataOutputStream(sk1.getOutputStream());
		if(checkString(s)==null)
		{
			dos.writeUTF(s+"\n");	
			System.out.println("String successfully sent as it is valid: "+s);		
		}
		else
		{
			System.out.println("String "+s+" Not Sent!");
			System.out.println("Illegal Word is used in the String to be sended: "+checkString(s));
		}		
	}
	public static String checkString(String s)throws IOException
	{
		BufferedReader br=new BufferedReader(new FileReader("keywords.txt"));
		String temp="";
		while((temp=br.readLine())!=null)
		{
			if((s.toUpperCase()).contains(temp))
			{
				return temp;
			}
		}
		return null;
	}
}
