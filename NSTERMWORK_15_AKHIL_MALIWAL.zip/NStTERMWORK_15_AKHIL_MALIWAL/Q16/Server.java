import java.io.*;
import java.net.*;

public class Server
{
	public static void main(String args[]) throws IOException
	{
		ServerSocket ss = new ServerSocket(3456);
		Socket con = ss.accept();
		
		DataInputStream input = new DataInputStream(con.getInputStream());
		String msg = input.readUTF();
		
		System.out.println("String successfully received: "+msg);
	}
}
